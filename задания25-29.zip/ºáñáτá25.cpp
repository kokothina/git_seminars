using System;
class HelloWorld {
  static void Main() {
    int stepen=1,i;
string[] num = Console.ReadLine().Split(' ');
               int a = int.Parse(num[0]);
               int b= int.Parse(num[1]);
    for (i = 0; i<b; i++)
    {
        stepen=stepen*a;
    }
    Console.Write(stepen);
}
}