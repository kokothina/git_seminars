using System;
class HelloWorld {
  static void Main() {
    int sum=0,i;
string[] num = Console.ReadLine().Split(' ');

    
      for(i = 0;i<num.Length;i++)
    {
        if (i==0)
        Console.Write("[");
        Console.Write(num[i]);
        if (i!=num.Length-1)
        Console.Write(",");
        if (i==num.Length-1)
        Console.Write("]");
    }
    
    
}
}