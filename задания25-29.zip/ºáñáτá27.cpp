using System;
class HelloWorld {
  static void Main() {
    int sum=0;
string[] num = Console.ReadLine().Split(' ');
               int n = int.Parse(num[0]);
  while (n != 0) {
    sum += n % 10;
    n /= 10;
  }
    Console.Write(sum);
}
}