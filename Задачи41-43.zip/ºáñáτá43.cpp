using System;
class HelloWorld {
  static void Main() {
var b1 = Convert.ToDouble(Console.ReadLine()); 
var k1 = Convert.ToDouble(Console.ReadLine());
var b2 = Convert.ToDouble(Console.ReadLine());
var k2 = Convert.ToDouble(Console.ReadLine()); //ВВОД КОЭФФИЦИЕНТОВ
var x = -(b1 - b2) / (k1 - k2); //ФОРМУЛА ДЛЯ ИКСА
var y = k1 * x + b1; //ФОРМУЛА ДЛЯ ИГРЕКА
Console.WriteLine($"({x};{y})"); //ВЫВОД ИКСА И ИГРЕКА
  }
}