using System;
class HelloWorld {
  static void Main() {
  int i;
string[] num = Console.ReadLine().Split(' '); //ВВОД МАССИВА В ФОРМАТЕ СТРОКИ
int [] intArray = new int[num.Length];  //СОЗДАНИЕ НОВОГО МАССИВА РАЗМЕРОВ С ВВЕДЕННОГО ВЫШЕ
for(i=0; i<num.Length; i++) 
{
     intArray[i] = int.Parse(num[i]); //ПРЕОБРАЗОВАНИЕ ЭЛЕМЕНТОВ МАССИВА NUM ИЗ СТРОКИ В ЧИСЛО
}
int count=0; //СОЗДАНИЕ СЧЕТЧИКА
foreach (int j in intArray)  //ПРОНИКНОВЕНИЕ В МАССИВ intAarray
{
    if (j>0) count++; //ПРОВЕРКА НА ПОЛОЖИТЕЛЬНОСТЬ С ПОСЛЕДУЮЩИМ ФИКСИРОВАНИЕМ
}
Console.WriteLine(count); //ВЫВОД ЧИСЛА СРАБАТЫВАНИЙ УСЛОВИЯ
  }
}
