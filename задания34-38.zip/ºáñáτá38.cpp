using System;
class HelloWorld {
  static void Main() {
    int sum=0,i;
string[] num = Console.ReadLine().Split(' ');
int [] doubleArray = new int[num.Length];
for(i=0; i<num.Length; i++)
{
     doubleArray[i] = int.Parse(num[i]);
}
int min = 1000;
int max = 0;
foreach (int j in doubleArray)  // Поиск максимального и минимального значения
{
    if (min > j) min = j;
    if (max < j) max = j;
}
Console.WriteLine(max-min);
}
}