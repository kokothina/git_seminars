using System;
class HelloWorld {
  static void Main() {
    int sum=0,i;
string[] num = Console.ReadLine().Split(' ');
      for(i = 0;i<num.Length;i++)
    {
        if (i%2==1)
        {
            sum = sum + Convert.ToInt32(num[i]);
        }
    }
    Console.WriteLine(sum);
}
}