using System;
class HelloWorld {
  static void Main() {
    int count=0,i;
string[] num = Console.ReadLine().Split(' ');
      for(i = 0;i<num.Length;i++)
    {
        if (Convert.ToInt32(num[i])%2==0)
        count++;
    }
    Console.WriteLine(count);
}
}